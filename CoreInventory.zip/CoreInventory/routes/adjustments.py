from flask import Blueprint, render_template, request, redirect, url_for, flash
from database import db, Product, StockMove
from routes.dashboard import login_required
from datetime import datetime

adjustments_bp = Blueprint("adjustments", __name__)


@adjustments_bp.route("/adjustments", methods=["GET", "POST"])
@login_required
def index():
    products = Product.query.order_by(Product.name).all()
    recent_adjustments = StockMove.query.filter_by(operation_type="adjustment").order_by(StockMove.date.desc()).limit(20).all()

    if request.method == "POST":
        product_id = request.form.get("product_id")
        counted_qty = request.form.get("counted_qty")
        reason = request.form.get("reason", "Physical count adjustment")

        if not product_id or counted_qty is None:
            flash("Product and counted quantity are required.", "danger")
            return render_template("adjustments/index.html", products=products, recent=recent_adjustments)

        product = Product.query.get_or_404(int(product_id))
        old_qty = product.stock_qty
        new_qty = float(counted_qty)
        diff = new_qty - old_qty

        product.stock_qty = new_qty
        ref = f"ADJ/{datetime.now().strftime('%Y%m%d%H%M%S')}"
        move = StockMove(
            product_id=product.id,
            operation_type="adjustment",
            qty_change=diff,
            reference=ref,
            location="WH001/Stock",
            notes=f"{reason} (was {old_qty}, counted {new_qty})"
        )
        db.session.add(move)
        db.session.commit()

        direction = "increased" if diff > 0 else "decreased" if diff < 0 else "unchanged"
        flash(f"Stock for '{product.name}' adjusted from {old_qty} to {new_qty} ({direction}).", "success")
        return redirect(url_for("adjustments.index"))

    return render_template("adjustments/index.html", products=products, recent=recent_adjustments)
