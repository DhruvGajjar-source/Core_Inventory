from flask import Blueprint, render_template, request, redirect, url_for, session, flash
from database import db, User
from otp_service import otp_store, send_otp, verify_otp_code

auth_bp = Blueprint("auth", __name__)


@auth_bp.route("/")
def index():
    if "user_id" in session:
        return redirect(url_for("dashboard.index"))
    return redirect(url_for("auth.login"))


@auth_bp.route("/signup", methods=["GET", "POST"])
def signup():
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        confirm = request.form.get("confirm_password", "")

        if not name or not email or not password:
            flash("All fields are required.", "danger")
            return render_template("auth/signup.html")

        if password != confirm:
            flash("Passwords do not match.", "danger")
            return render_template("auth/signup.html")

        if User.query.filter_by(email=email).first():
            flash("Email already registered.", "danger")
            return render_template("auth/signup.html")

        user = User(name=name, email=email)
        user.set_password(password)
        db.session.add(user)
        db.session.commit()
        flash("Account created! Please log in.", "success")
        return redirect(url_for("auth.login"))

    return render_template("auth/signup.html")


@auth_bp.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        user = User.query.filter_by(email=email).first()

        if user and user.check_password(password):
            session["user_id"] = user.id
            session["user_name"] = user.name
            session["user_email"] = user.email
            flash(f"Welcome back, {user.name}!", "success")
            return redirect(url_for("dashboard.index"))
        else:
            flash("Invalid email or password.", "danger")

    return render_template("auth/login.html")


@auth_bp.route("/logout")
def logout():
    session.clear()
    flash("You have been logged out.", "info")
    return redirect(url_for("auth.login"))


@auth_bp.route("/forgot-password", methods=["GET", "POST"])
def forgot_password():
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        user = User.query.filter_by(email=email).first()
        if user:
            result = send_otp(email)
            if result["ok"]:
                flash(result["message"], "info")
                return redirect(url_for("auth.verify_otp", email=email))
            else:
                flash(result["message"], "danger")
        else:
            # Don't reveal whether the email exists — always show the same message
            flash("If that email is registered, an OTP has been sent.", "info")
            return redirect(url_for("auth.verify_otp", email=email))

    return render_template("auth/forgot_password.html")


@auth_bp.route("/verify-otp", methods=["GET", "POST"])
def verify_otp():
    email = request.args.get("email", "")
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        entered_otp = request.form.get("otp", "").strip()

        result = verify_otp_code(email, entered_otp)
        if result["ok"]:
            session["reset_email"] = email
            return redirect(url_for("auth.reset_password"))
        else:
            flash(result["message"], "danger")

    entry = otp_store.get(email)
    otp_info = None
    if entry:
        import time
        remaining = max(0, int(entry["expires_at"] - time.time()))
        otp_info = {"remaining": remaining, "attempts_left": 3 - entry.get("attempts", 0)}

    return render_template("auth/verify_otp.html", email=email, otp_info=otp_info)


@auth_bp.route("/forgot-password/resend", methods=["POST"])
def resend_otp():
    email = request.form.get("email", "").strip().lower()
    user = User.query.filter_by(email=email).first()
    if user:
        result = send_otp(email, force=True)
        flash(result["message"], "info" if result["ok"] else "danger")
    return redirect(url_for("auth.verify_otp", email=email))


@auth_bp.route("/reset-password", methods=["GET", "POST"])
def reset_password():
    email = session.get("reset_email")
    if not email:
        return redirect(url_for("auth.forgot_password"))

    if request.method == "POST":
        new_password = request.form.get("new_password", "")
        confirm = request.form.get("confirm_password", "")
        if new_password != confirm:
            flash("Passwords do not match.", "danger")
        elif len(new_password) < 6:
            flash("Password must be at least 6 characters.", "danger")
        else:
            user = User.query.filter_by(email=email).first()
            if user:
                user.set_password(new_password)
                db.session.commit()
                session.pop("reset_email", None)
                otp_store.pop(email, None)
                flash("Password reset successful! Please log in.", "success")
                return redirect(url_for("auth.login"))

    return render_template("auth/reset_password.html", email=email)
