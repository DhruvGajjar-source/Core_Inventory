from flask import Blueprint, render_template, session, redirect, url_for
from database import db, Product, Receipt, DeliveryOrder, InternalTransfer, StockMove, Category
from sqlalchemy import func
from datetime import datetime, timedelta
from functools import wraps

dashboard_bp = Blueprint("dashboard", __name__)


def login_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if "user_id" not in session:
            return redirect(url_for("auth.login"))
        return f(*args, **kwargs)
    return decorated


@dashboard_bp.route("/dashboard")
@login_required
def index():
    total_products = Product.query.count()
    low_stock = Product.query.filter(
        Product.stock_qty > 0, Product.stock_qty <= Product.reorder_threshold
    ).count()
    out_of_stock = Product.query.filter(Product.stock_qty <= 0).count()
    pending_receipts = Receipt.query.filter(Receipt.status.in_(["draft", "ready"])).count()
    pending_deliveries = DeliveryOrder.query.filter(DeliveryOrder.status.in_(["draft", "ready", "picked", "packed"])).count()
    pending_transfers = InternalTransfer.query.filter(InternalTransfer.status.in_(["draft", "ready"])).count()

    recent_moves = StockMove.query.order_by(StockMove.date.desc()).limit(10).all()

    # Category-wise stock summary
    cat_summary = (
        db.session.query(Category.name, func.sum(Product.stock_qty))
        .join(Product, Product.category_id == Category.id)
        .group_by(Category.name)
        .all()
    )

    return render_template(
        "dashboard/index.html",
        total_products=total_products,
        low_stock=low_stock,
        out_of_stock=out_of_stock,
        pending_receipts=pending_receipts,
        pending_deliveries=pending_deliveries,
        pending_transfers=pending_transfers,
        recent_moves=recent_moves,
        cat_summary=cat_summary,
    )
