from flask import Blueprint, render_template, request, redirect, url_for, flash
from database import db, DeliveryOrder, DeliveryLine, Product, StockMove
from routes.dashboard import login_required
from datetime import datetime

deliveries_bp = Blueprint("deliveries", __name__)


def next_delivery_ref():
    count = DeliveryOrder.query.count() + 1
    return f"OUT/{datetime.now().strftime('%Y%m')}/{count:04d}"


@deliveries_bp.route("/deliveries")
@login_required
def index():
    status_filter = request.args.get("status", "")
    query = DeliveryOrder.query
    if status_filter:
        query = query.filter(DeliveryOrder.status == status_filter)
    deliveries = query.order_by(DeliveryOrder.created_at.desc()).all()
    return render_template("deliveries/index.html", deliveries=deliveries, status_filter=status_filter)


@deliveries_bp.route("/deliveries/new", methods=["GET", "POST"])
@login_required
def new():
    products = Product.query.filter(Product.stock_qty > 0).order_by(Product.name).all()
    if request.method == "POST":
        customer = request.form.get("customer_name", "").strip()
        notes = request.form.get("notes", "")
        if not customer:
            flash("Customer name is required.", "danger")
            return render_template("deliveries/form.html", products=products, delivery=None)

        delivery = DeliveryOrder(reference=next_delivery_ref(), customer_name=customer, notes=notes)
        db.session.add(delivery)
        db.session.flush()

        product_ids = request.form.getlist("product_id[]")
        quantities = request.form.getlist("qty_ordered[]")
        for pid, qty in zip(product_ids, quantities):
            if pid and qty:
                try:
                    line = DeliveryLine(delivery_id=delivery.id, product_id=int(pid),
                                       qty_ordered=float(qty), qty_done=0)
                    db.session.add(line)
                except (ValueError, TypeError):
                    pass

        db.session.commit()
        flash(f"Delivery Order {delivery.reference} created.", "success")
        return redirect(url_for("deliveries.detail", delivery_id=delivery.id))

    return render_template("deliveries/form.html", products=products, delivery=None)


@deliveries_bp.route("/deliveries/<int:delivery_id>")
@login_required
def detail(delivery_id):
    delivery = DeliveryOrder.query.get_or_404(delivery_id)
    return render_template("deliveries/detail.html", delivery=delivery)


@deliveries_bp.route("/deliveries/<int:delivery_id>/pick", methods=["POST"])
@login_required
def pick(delivery_id):
    delivery = DeliveryOrder.query.get_or_404(delivery_id)
    if delivery.status == "draft":
        # Check stock availability
        errors = []
        for line in delivery.lines:
            if line.product.stock_qty < line.qty_ordered:
                errors.append(f"{line.product.name}: only {line.product.stock_qty} {line.product.uom} available")
        if errors:
            for e in errors:
                flash(e, "danger")
        else:
            delivery.status = "picked"
            db.session.commit()
            flash(f"Delivery {delivery.reference} picked.", "success")
    return redirect(url_for("deliveries.detail", delivery_id=delivery_id))


@deliveries_bp.route("/deliveries/<int:delivery_id>/pack", methods=["POST"])
@login_required
def pack(delivery_id):
    delivery = DeliveryOrder.query.get_or_404(delivery_id)
    if delivery.status == "picked":
        delivery.status = "packed"
        db.session.commit()
        flash(f"Delivery {delivery.reference} packed.", "success")
    return redirect(url_for("deliveries.detail", delivery_id=delivery_id))


@deliveries_bp.route("/deliveries/<int:delivery_id>/validate", methods=["POST"])
@login_required
def validate(delivery_id):
    delivery = DeliveryOrder.query.get_or_404(delivery_id)
    if delivery.status not in ("packed", "picked", "draft", "ready"):
        flash("Cannot validate this delivery.", "warning")
        return redirect(url_for("deliveries.detail", delivery_id=delivery_id))

    errors = []
    for line in delivery.lines:
        qty = float(request.form.get(f"qty_done_{line.id}", line.qty_ordered))
        if line.product.stock_qty < qty:
            errors.append(f"Insufficient stock for {line.product.name}.")

    if errors:
        for e in errors:
            flash(e, "danger")
        return redirect(url_for("deliveries.detail", delivery_id=delivery_id))

    for line in delivery.lines:
        qty = float(request.form.get(f"qty_done_{line.id}", line.qty_ordered))
        line.qty_done = qty
        line.product.stock_qty -= qty
        move = StockMove(
            product_id=line.product_id,
            operation_type="delivery",
            qty_change=-qty,
            reference=delivery.reference,
            location="WH001/Stock → Customers",
            notes=f"Delivery to {delivery.customer_name}"
        )
        db.session.add(move)

    delivery.status = "done"
    delivery.validated_at = datetime.utcnow()
    db.session.commit()
    flash(f"Delivery {delivery.reference} completed. Stock updated.", "success")
    return redirect(url_for("deliveries.detail", delivery_id=delivery_id))


@deliveries_bp.route("/deliveries/<int:delivery_id>/delete", methods=["POST"])
@login_required
def delete(delivery_id):
    delivery = DeliveryOrder.query.get_or_404(delivery_id)
    if delivery.status == "done":
        flash("Cannot delete a completed delivery.", "danger")
        return redirect(url_for("deliveries.detail", delivery_id=delivery_id))
    db.session.delete(delivery)
    db.session.commit()
    flash("Delivery order deleted.", "info")
    return redirect(url_for("deliveries.index"))
