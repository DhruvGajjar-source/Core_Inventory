from flask import Blueprint, render_template, request
from database import db, StockMove, Product, Category
from routes.dashboard import login_required

history_bp = Blueprint("history", __name__)


@history_bp.route("/history")
@login_required
def index():
    op_filter = request.args.get("op_type", "")
    category_filter = request.args.get("category", "")
    page = request.args.get("page", 1, type=int)

    query = StockMove.query
    if op_filter:
        query = query.filter(StockMove.operation_type == op_filter)
    if category_filter:
        try:
            query = query.join(Product).filter(Product.category_id == int(category_filter))
        except (ValueError, TypeError):
            pass

    moves = query.order_by(StockMove.date.desc()).paginate(page=page, per_page=25, error_out=False)
    categories = Category.query.order_by(Category.name).all()
    return render_template("history/index.html", moves=moves, op_filter=op_filter,
                           category_filter=category_filter, categories=categories)
