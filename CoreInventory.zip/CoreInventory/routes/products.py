from flask import Blueprint, render_template, request, redirect, url_for, flash, session
from database import db, Product, Category, StockMove
from routes.dashboard import login_required
from datetime import datetime

products_bp = Blueprint("products", __name__)


@products_bp.route("/products")
@login_required
def index():
    search = request.args.get("search", "").strip()
    category_filter = request.args.get("category", "")
    query = Product.query
    if search:
        query = query.filter(Product.sku.ilike(f"%{search}%") | Product.name.ilike(f"%{search}%"))
    if category_filter:
        query = query.filter(Product.category_id == category_filter)
    products = query.order_by(Product.name).all()
    categories = Category.query.order_by(Category.name).all()
    return render_template("products/index.html", products=products, categories=categories,
                           search=search, category_filter=category_filter)


@products_bp.route("/products/new", methods=["GET", "POST"])
@login_required
def new():
    categories = Category.query.order_by(Category.name).all()
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        sku = request.form.get("sku", "").strip().upper()
        category_id = request.form.get("category_id") or None
        uom = request.form.get("uom", "Units")
        initial_stock = float(request.form.get("initial_stock", 0))
        reorder_threshold = float(request.form.get("reorder_threshold", 10))

        if not name or not sku:
            flash("Name and SKU are required.", "danger")
            return render_template("products/form.html", categories=categories, product=None)

        if Product.query.filter_by(sku=sku).first():
            flash("SKU already exists.", "danger")
            return render_template("products/form.html", categories=categories, product=None)

        product = Product(
            name=name, sku=sku, category_id=category_id,
            uom=uom, stock_qty=initial_stock, reorder_threshold=reorder_threshold
        )
        db.session.add(product)
        db.session.flush()

        if initial_stock > 0:
            move = StockMove(
                product_id=product.id,
                operation_type="adjustment",
                qty_change=initial_stock,
                reference="Initial Stock",
                location="WH001/Stock",
                notes="Initial stock entry"
            )
            db.session.add(move)

        db.session.commit()
        flash(f"Product '{name}' created successfully.", "success")
        return redirect(url_for("products.index"))

    return render_template("products/form.html", categories=categories, product=None)


@products_bp.route("/products/<int:product_id>/edit", methods=["GET", "POST"])
@login_required
def edit(product_id):
    product = Product.query.get_or_404(product_id)
    categories = Category.query.order_by(Category.name).all()
    if request.method == "POST":
        product.name = request.form.get("name", product.name).strip()
        new_sku = request.form.get("sku", product.sku).strip().upper()
        existing = Product.query.filter_by(sku=new_sku).first()
        if existing and existing.id != product.id:
            flash("SKU already in use.", "danger")
            return render_template("products/form.html", categories=categories, product=product)

        product.sku = new_sku
        product.category_id = request.form.get("category_id") or None
        product.uom = request.form.get("uom", product.uom)
        product.reorder_threshold = float(request.form.get("reorder_threshold", product.reorder_threshold))
        db.session.commit()
        flash(f"Product '{product.name}' updated.", "success")
        return redirect(url_for("products.index"))

    return render_template("products/form.html", categories=categories, product=product)


@products_bp.route("/products/<int:product_id>")
@login_required
def detail(product_id):
    product = Product.query.get_or_404(product_id)
    moves = StockMove.query.filter_by(product_id=product_id).order_by(StockMove.date.desc()).limit(20).all()
    return render_template("products/detail.html", product=product, moves=moves)
