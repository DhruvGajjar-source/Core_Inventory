from flask import Blueprint, render_template, request, redirect, url_for, flash, session
from database import db, Receipt, ReceiptLine, Product, StockMove
from routes.dashboard import login_required
from datetime import datetime

receipts_bp = Blueprint("receipts", __name__)


def next_receipt_ref():
    count = Receipt.query.count() + 1
    return f"REC/{datetime.now().strftime('%Y%m')}/{count:04d}"


@receipts_bp.route("/receipts")
@login_required
def index():
    status_filter = request.args.get("status", "")
    query = Receipt.query
    if status_filter:
        query = query.filter(Receipt.status == status_filter)
    receipts = query.order_by(Receipt.created_at.desc()).all()
    return render_template("receipts/index.html", receipts=receipts, status_filter=status_filter)


@receipts_bp.route("/receipts/new", methods=["GET", "POST"])
@login_required
def new():
    products = Product.query.order_by(Product.name).all()
    if request.method == "POST":
        supplier = request.form.get("supplier_name", "").strip()
        notes = request.form.get("notes", "")
        if not supplier:
            flash("Supplier name is required.", "danger")
            return render_template("receipts/form.html", products=products, receipt=None)

        receipt = Receipt(reference=next_receipt_ref(), supplier_name=supplier, notes=notes)
        db.session.add(receipt)
        db.session.flush()

        product_ids = request.form.getlist("product_id[]")
        quantities = request.form.getlist("qty_ordered[]")
        for pid, qty in zip(product_ids, quantities):
            if pid and qty:
                try:
                    line = ReceiptLine(receipt_id=receipt.id, product_id=int(pid),
                                      qty_ordered=float(qty), qty_received=0)
                    db.session.add(line)
                except (ValueError, TypeError):
                    pass

        db.session.commit()
        flash(f"Receipt {receipt.reference} created.", "success")
        return redirect(url_for("receipts.detail", receipt_id=receipt.id))

    return render_template("receipts/form.html", products=products, receipt=None)


@receipts_bp.route("/receipts/<int:receipt_id>")
@login_required
def detail(receipt_id):
    receipt = Receipt.query.get_or_404(receipt_id)
    return render_template("receipts/detail.html", receipt=receipt)


@receipts_bp.route("/receipts/<int:receipt_id>/confirm", methods=["POST"])
@login_required
def confirm(receipt_id):
    receipt = Receipt.query.get_or_404(receipt_id)
    if receipt.status == "draft":
        receipt.status = "ready"
        db.session.commit()
        flash(f"Receipt {receipt.reference} marked as Ready.", "success")
    return redirect(url_for("receipts.detail", receipt_id=receipt_id))


@receipts_bp.route("/receipts/<int:receipt_id>/validate", methods=["POST"])
@login_required
def validate(receipt_id):
    receipt = Receipt.query.get_or_404(receipt_id)
    if receipt.status not in ("ready", "draft"):
        flash("Receipt already validated.", "warning")
        return redirect(url_for("receipts.detail", receipt_id=receipt_id))

    for line in receipt.lines:
        qty = float(request.form.get(f"qty_received_{line.id}", line.qty_ordered))
        line.qty_received = qty
        line.product.stock_qty += qty
        move = StockMove(
            product_id=line.product_id,
            operation_type="receipt",
            qty_change=qty,
            reference=receipt.reference,
            location="Suppliers → WH001/Stock",
            notes=f"Receipt from {receipt.supplier_name}"
        )
        db.session.add(move)

    receipt.status = "done"
    receipt.validated_at = datetime.utcnow()
    db.session.commit()
    flash(f"Receipt {receipt.reference} validated. Stock updated.", "success")
    return redirect(url_for("receipts.detail", receipt_id=receipt_id))


@receipts_bp.route("/receipts/<int:receipt_id>/delete", methods=["POST"])
@login_required
def delete(receipt_id):
    receipt = Receipt.query.get_or_404(receipt_id)
    if receipt.status == "done":
        flash("Cannot delete a validated receipt.", "danger")
        return redirect(url_for("receipts.detail", receipt_id=receipt_id))
    db.session.delete(receipt)
    db.session.commit()
    flash("Receipt deleted.", "info")
    return redirect(url_for("receipts.index"))
