from flask import Blueprint, render_template, request, redirect, url_for, flash, session
from database import db, Warehouse, Location, Category, User
from routes.dashboard import login_required

settings_bp = Blueprint("settings", __name__)


@settings_bp.route("/settings")
@login_required
def index():
    warehouse = Warehouse.query.first()
    locations = Location.query.order_by(Location.location_type, Location.name).all()
    categories = Category.query.order_by(Category.name).all()
    user = User.query.get(session["user_id"])
    return render_template("settings/index.html", warehouse=warehouse, locations=locations,
                           categories=categories, user=user)


@settings_bp.route("/settings/warehouse", methods=["POST"])
@login_required
def update_warehouse():
    warehouse = Warehouse.query.first()
    if warehouse:
        warehouse.name = request.form.get("name", warehouse.name)
        warehouse.code = request.form.get("code", warehouse.code)
        warehouse.address = request.form.get("address", warehouse.address)
        db.session.commit()
        flash("Warehouse settings updated.", "success")
    return redirect(url_for("settings.index"))


@settings_bp.route("/settings/categories/new", methods=["POST"])
@login_required
def new_category():
    name = request.form.get("name", "").strip()
    if name:
        if Category.query.filter_by(name=name).first():
            flash("Category already exists.", "warning")
        else:
            db.session.add(Category(name=name))
            db.session.commit()
            flash(f"Category '{name}' added.", "success")
    return redirect(url_for("settings.index"))


@settings_bp.route("/settings/profile", methods=["POST"])
@login_required
def update_profile():
    user = User.query.get(session["user_id"])
    user.name = request.form.get("name", user.name).strip()
    new_password = request.form.get("new_password", "")
    if new_password:
        user.set_password(new_password)
        flash("Password updated.", "success")
    db.session.commit()
    session["user_name"] = user.name
    flash("Profile updated.", "success")
    return redirect(url_for("settings.index"))
