from flask import Blueprint, render_template, request, redirect, url_for, flash
from database import db, InternalTransfer, TransferLine, Product, Location, StockMove
from routes.dashboard import login_required
from datetime import datetime

transfers_bp = Blueprint("transfers", __name__)


def next_transfer_ref():
    count = InternalTransfer.query.count() + 1
    return f"INT/{datetime.now().strftime('%Y%m')}/{count:04d}"


@transfers_bp.route("/transfers")
@login_required
def index():
    transfers = InternalTransfer.query.order_by(InternalTransfer.created_at.desc()).all()
    return render_template("transfers/index.html", transfers=transfers)


@transfers_bp.route("/transfers/new", methods=["GET", "POST"])
@login_required
def new():
    products = Product.query.filter(Product.stock_qty > 0).order_by(Product.name).all()
    locations = Location.query.filter_by(location_type="internal").order_by(Location.full_name).all()
    if request.method == "POST":
        from_loc_id = request.form.get("from_location_id") or None
        to_loc_id = request.form.get("to_location_id") or None
        notes = request.form.get("notes", "")

        transfer = InternalTransfer(
            reference=next_transfer_ref(),
            from_location_id=from_loc_id,
            to_location_id=to_loc_id,
            notes=notes
        )
        db.session.add(transfer)
        db.session.flush()

        product_ids = request.form.getlist("product_id[]")
        quantities = request.form.getlist("qty[]")
        for pid, qty in zip(product_ids, quantities):
            if pid and qty:
                try:
                    line = TransferLine(transfer_id=transfer.id, product_id=int(pid), qty=float(qty))
                    db.session.add(line)
                except (ValueError, TypeError):
                    pass

        db.session.commit()
        flash(f"Transfer {transfer.reference} created.", "success")
        return redirect(url_for("transfers.detail", transfer_id=transfer.id))

    return render_template("transfers/form.html", products=products, locations=locations)


@transfers_bp.route("/transfers/<int:transfer_id>")
@login_required
def detail(transfer_id):
    transfer = InternalTransfer.query.get_or_404(transfer_id)
    return render_template("transfers/detail.html", transfer=transfer)


@transfers_bp.route("/transfers/<int:transfer_id>/validate", methods=["POST"])
@login_required
def validate(transfer_id):
    transfer = InternalTransfer.query.get_or_404(transfer_id)
    if transfer.status == "done":
        flash("Transfer already validated.", "warning")
        return redirect(url_for("transfers.detail", transfer_id=transfer_id))

    from_name = transfer.from_location.full_name if transfer.from_location else "Unknown"
    to_name = transfer.to_location.full_name if transfer.to_location else "Unknown"

    for line in transfer.lines:
        if line.product.stock_qty < line.qty:
            flash(f"Insufficient stock for {line.product.name}.", "danger")
            return redirect(url_for("transfers.detail", transfer_id=transfer_id))

    for line in transfer.lines:
        # Stock total unchanged — just log the move
        move = StockMove(
            product_id=line.product_id,
            operation_type="transfer",
            qty_change=0,
            reference=transfer.reference,
            location=f"{from_name} → {to_name}",
            notes=f"Internal transfer: {line.qty} {line.product.uom} moved"
        )
        db.session.add(move)

    transfer.status = "done"
    transfer.validated_at = datetime.utcnow()
    db.session.commit()
    flash(f"Transfer {transfer.reference} validated.", "success")
    return redirect(url_for("transfers.detail", transfer_id=transfer_id))


@transfers_bp.route("/transfers/<int:transfer_id>/delete", methods=["POST"])
@login_required
def delete(transfer_id):
    transfer = InternalTransfer.query.get_or_404(transfer_id)
    if transfer.status == "done":
        flash("Cannot delete a completed transfer.", "danger")
        return redirect(url_for("transfers.detail", transfer_id=transfer_id))
    db.session.delete(transfer)
    db.session.commit()
    flash("Transfer deleted.", "info")
    return redirect(url_for("transfers.index"))
