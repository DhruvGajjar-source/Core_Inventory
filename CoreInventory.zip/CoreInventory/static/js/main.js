// CoreInventory — minimal JS helpers

// Auto-dismiss flash alerts after 5 seconds (also handled inline in base.html)
document.addEventListener('DOMContentLoaded', function () {
  setTimeout(function () {
    document.querySelectorAll('.alert').forEach(function (el) {
      var a = bootstrap.Alert.getOrCreateInstance(el);
      if (a) a.close();
    });
  }, 5000);
});
